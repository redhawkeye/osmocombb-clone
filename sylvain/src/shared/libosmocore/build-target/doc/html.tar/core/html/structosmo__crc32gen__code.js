var structosmo__crc32gen__code =
[
    [ "bits", "group__crcgen.html#gab7ea0542721265f02d540fc95fb48fda", null ],
    [ "init", "group__crcgen.html#gad139d035aff276d724db17c41b2147d8", null ],
    [ "poly", "group__crcgen.html#ga38fbc53e41d3181a2123c62253f9ee25", null ],
    [ "remainder", "group__crcgen.html#gaa0fc5a5c0a648855bae5d975fc8829c1", null ]
];
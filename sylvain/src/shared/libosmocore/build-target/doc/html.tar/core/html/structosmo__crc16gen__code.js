var structosmo__crc16gen__code =
[
    [ "bits", "group__crcgen.html#ga96292309cf771e1086f86ccfd4bac9b2", null ],
    [ "init", "group__crcgen.html#gaecf697df2c87f82d77273fc3170f06b2", null ],
    [ "poly", "group__crcgen.html#gaedd08f5b95d016f3f09fc8bd7941c4e3", null ],
    [ "remainder", "group__crcgen.html#gaeff1e62578a8f7b2474aa8765b9b874d", null ]
];
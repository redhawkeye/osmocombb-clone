var structosmo__crc8gen__code =
[
    [ "bits", "group__crcgen.html#ga9a2de2bd7a3809d82b83a25641129520", null ],
    [ "init", "group__crcgen.html#gade3db78e0cda5fdae402c734d5977f1f", null ],
    [ "poly", "group__crcgen.html#ga40cbd268cfea5c97f8380def8fd7baf2", null ],
    [ "remainder", "group__crcgen.html#gafe19aa4b075e3438d90c7ba46542d779", null ]
];
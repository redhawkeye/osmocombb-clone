var dir_f8141cd6930ff3040f762819de28fd89 =
[
    [ "osmocom", "dir_8bd8336b40c4234e432a913bcd8b4c5c.html", "dir_8bd8336b40c4234e432a913bcd8b4c5c" ]
];
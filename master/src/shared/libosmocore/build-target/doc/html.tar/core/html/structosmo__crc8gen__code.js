var structosmo__crc8gen__code =
[
    [ "bits", "structosmo__crc8gen__code.html#a9a2de2bd7a3809d82b83a25641129520", null ],
    [ "init", "structosmo__crc8gen__code.html#ade3db78e0cda5fdae402c734d5977f1f", null ],
    [ "poly", "structosmo__crc8gen__code.html#a40cbd268cfea5c97f8380def8fd7baf2", null ],
    [ "remainder", "structosmo__crc8gen__code.html#afe19aa4b075e3438d90c7ba46542d779", null ]
];
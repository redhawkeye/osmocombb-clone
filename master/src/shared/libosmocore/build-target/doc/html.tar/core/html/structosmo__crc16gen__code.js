var structosmo__crc16gen__code =
[
    [ "bits", "structosmo__crc16gen__code.html#a96292309cf771e1086f86ccfd4bac9b2", null ],
    [ "init", "structosmo__crc16gen__code.html#aecf697df2c87f82d77273fc3170f06b2", null ],
    [ "poly", "structosmo__crc16gen__code.html#aedd08f5b95d016f3f09fc8bd7941c4e3", null ],
    [ "remainder", "structosmo__crc16gen__code.html#aeff1e62578a8f7b2474aa8765b9b874d", null ]
];